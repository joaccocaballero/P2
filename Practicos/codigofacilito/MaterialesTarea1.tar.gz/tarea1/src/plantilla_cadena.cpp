/* abcdefg */ // sustituiir con los 7 dígitos de la cédula

#include "../include/cadena.h"

// los elementos se mantienen entre 0 y cantidad - 1, incluidos
struct _rep_cadena {};

TCadena crearCadena() {
  return NULL;
}

/* en siguientes tareas
void liberarCadena(TCadena cad) {
}
*/

nat cantidadEnCadena(TCadena cad) {
  return 0;
}

bool estaEnCadena(nat natural, TCadena cad) {
  return false;
}

TCadena insertarAlInicio(nat natural, double real, TCadena cad) {
  return NULL;
}

TInfo infoCadena(nat natural, TCadena cad) {
  return NULL;
}

TCadena removerDeCadena(nat natural, TCadena cad) {
  return NULL;
}

void imprimirCadena(TCadena cad) {
}
